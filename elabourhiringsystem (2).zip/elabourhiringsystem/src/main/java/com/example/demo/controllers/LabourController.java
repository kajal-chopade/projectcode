package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Labour1;
import com.example.demo.entities.Users;
import com.example.demo.services.LabourServices;

@RestController
@RequestMapping("/labour")
public class LabourController
{

	@Autowired
	LabourServices lservices;
	
	@GetMapping("/alllabours")
	public List<Labour1>getAll()
	{
		return lservices.getAll();
	}
	
	@PostMapping("/savelabour")
	public Labour1 save(@RequestBody Labour1 l)
	{
		return lservices.savelabour(l);
	}
	

	 @GetMapping("/getone")
	public Labour1 getOne(@RequestParam("labour_id") int labour_id)
	{
		return lservices.getOne(labour_id);
	}
	
	@GetMapping("/getlabour/{labour_id}")
	public Labour1 getLabour(@PathVariable("labour_id") int id)
	{
		return lservices.getOne(id);
	}
	
	@GetMapping("/getlabour/{labour_id}/{labour_type}")//multi pathvariable in one request
	public Labour1 getUser(@PathVariable("labour_id") int id,@PathVariable("labour_type") String labour_type)
	{
		return lservices.getOne(id);
	}
	
}
