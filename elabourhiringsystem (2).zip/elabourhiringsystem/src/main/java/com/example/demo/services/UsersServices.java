package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Users;
import com.example.demo.repositories.UserRepository;

@Service
public class UsersServices 
{
	@Autowired
	UserRepository urepos;
	
	public String checkLogin(int user_id,String password)
	{
		return urepos.checkLogin(user_id, password);
	}
	
	
	public List<Users>getAll()
	{
		return urepos.findAll();//repository provide findAll()function
	}
	
	public Users save(Users u)
	{
		return urepos.save(u);//repository provide save()function
	}
	
	
	 public Users getOne(int user_id)
	{
		Optional <Users>user =urepos.findById(user_id);
		Users u=null;
		
		try
		{
			u=user.get();
		}catch(NoSuchElementException e)
		{
			u=null;
		}
		return u;
		
	}
}
