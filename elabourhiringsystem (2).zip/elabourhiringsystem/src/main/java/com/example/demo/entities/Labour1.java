package com.example.demo.entities;

import javax.persistence.CascadeType;

//import java.util.ArrayList;
//import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
//import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.Inheritance;
//import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
//import javax.persistence.OneToMany;
//import javax.persistence.OneToOne;
import javax.persistence.Table;

//import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@Entity
//@PrimaryKeyJoinColumn(name="user_id")
@Table(name="labour")
public class Labour1 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int labour_id;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="user_id",insertable = true,updatable = true)
	private Users user_id;
	
	@Column
	private String labour_type;
	/*@JsonIgnoreProperties("labour")
	@OneToMany(mappedBy = "user_id")
	List<Users>users=new ArrayList<Users>();*/
	
	
	public Labour1() {
		
	}


	public Labour1(int labour_id, Users user_id, String labour_type) {
		super();
		this.labour_id = labour_id;
		this.user_id = user_id;
		this.labour_type = labour_type;
	}


	public int getLabour_id() {
		return labour_id;
	}


	public void setLabour_id(int labour_id) {
		this.labour_id = labour_id;
	}


	public Users getUser_id() {
		return user_id;
	}


	public void setUser_id(Users user_id) {
		this.user_id = user_id;
	}


	public String getLabour_type() {
		return labour_type;
	}


	public void setLabour_type(String labour_type) {
		this.labour_type = labour_type;
	}


	@Override
	public String toString() {
		return "Labour1 [labour_id=" + labour_id + ", user_id=" + user_id + ", labour_type=" + labour_type + "]";
	}


	
	
}
