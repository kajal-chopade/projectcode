package com.example.demo.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Labour1;
import com.example.demo.repositories.LabourRepository;

@Service
public class LabourServices 
{
	@Autowired
	LabourRepository lrepos;
	public List<Labour1>getAll()
	{
		return lrepos.findAll();
	}

	public Labour1 savelabour(Labour1 l)
	{
		return lrepos.save(l);//repository provide save()function
	}
	
	
	 public Labour1 getOne(int labour_id)
	{
		Optional <Labour1>labour =lrepos.findById(labour_id);
		Labour1 l=null;
		
		try
		{
			l=labour.get();
		}catch(NoSuchElementException e)
		{
			l=null;
		}
		return l;
		
	}
	 
	 
}
