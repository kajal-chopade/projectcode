package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Users;
import com.example.demo.services.UsersServices;
@CrossOrigin(origins ="http://localhost:3000")
@RestController
@RequestMapping("/user")
public class UsersController 
{

	@Autowired
	UsersServices uservices;
	
	@GetMapping("/checkLogin")
	public String checkLogin(@RequestParam ("user_id") int user_id,@RequestParam ("password") String password)
	{
		return uservices.checkLogin(user_id, password);
	}
	
	@GetMapping("/all")
	public List<Users>getAll()
	{
		return uservices.getAll();
	}
	
	@PostMapping("/save")
	public Users save(@RequestBody Users u)
	{
		return uservices.save(u);
	}
	
	
	 @GetMapping("/getone")
	public Users getOne(@RequestParam("user_id") int user_id)
	{
		return uservices.getOne(user_id);
	}
	
	@GetMapping("/getuser/{user_id}")
	public Users getUser(@PathVariable("user_id") int id)
	{
		return uservices.getOne(id);
	}
	
	@GetMapping("/getuser/{user_id}/{fname}")//multi pathvariable in one request
	public Users getUser(@PathVariable("user_id") int id,@PathVariable("fname") String fname)
	{
		return uservices.getOne(id);
	}
	
}
